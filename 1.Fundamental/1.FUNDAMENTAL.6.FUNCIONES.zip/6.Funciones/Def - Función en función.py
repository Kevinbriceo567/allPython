def mensajes(solucion):
    return "El resultado es: " + solucion


def sumar(n1, n2):
    sol = 0
    sol = n1 + n2
    print(mensajes(str(sol)))


sumar(3, 5)
import math

print(math.pow(2, 3))