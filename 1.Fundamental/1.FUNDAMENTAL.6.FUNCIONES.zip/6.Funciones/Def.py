def mensaje(a, b):
    print("Hola amigo")
    print("Como estás")
    print("Todo bien?")

    return a + b

num1 = 3
num2 = 5

print(mensaje(num1, num2))

###############################
def lista(nombre1, nombre2, nombre3):

    listaNombres = [nombre1, nombre2, nombre3]

    return listaNombres

print(lista("Kevin", "Ingrid", "Willians"))